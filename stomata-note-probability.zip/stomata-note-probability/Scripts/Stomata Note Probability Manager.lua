-- Stomata Note Probability Manager
-- Run once as a REAPER startup action. This windowless service supplies the
-- selection-editing part of the Stomata JSFX user interface.

local SEGMENT = "StomataNoteProbability"
local MAGIC = 1398031693
local MARKER_LEAD_PPQ = 1
local CLIENT_TABLE_BASE, CLIENT_MAILBOX_SIZE = 64, 16
local CLIENT_RECORDS_BASE, RECORD_SIZE = 1024, 8
local MAX_CLIENTS, MAX_NOTES_PER_CLIENT = 32, 512

-- Shared-memory layout. All request data is written before request_id.
local SLOT_MAGIC, SLOT_HEARTBEAT = 0, 1
local SLOT_REQUEST_ID, SLOT_COMMAND, SLOT_GENERATION, SLOT_COUNT = 2, 3, 4, 5
local SLOT_RESPONSE_ID, SLOT_STATUS, SLOT_RESULT_GENERATION, SLOT_RESULT_COUNT = 6, 7, 8, 9

local COMMAND_REFRESH, COMMAND_APPLY = 1, 2
local STATUS_READY, STATUS_LOADED, STATUS_APPLIED = 0, 1, 2
local ERROR_NO_EDITOR, ERROR_NO_SELECTION, ERROR_STALE = -1, -2, -3
local ERROR_AMBIGUOUS, ERROR_INVALID = -4, -5

-- The manager serves one mailbox per open JSFX instance. `state` and the
-- current offsets are switched by service() before each request is handled.
local states, state = {}, nil
local mailbox_base, records_base = 0, 0

reaper.gmem_attach(SEGMENT)

local function clamp_probability(value)
  value = tonumber(value) or 100
  return math.max(0, math.min(100, math.floor(value * 10 + 0.5) / 10))
end

local function marker_text(probability, channel, pitch)
  -- Channel and pitch make simultaneous chord notes independently addressable.
  return string.format("P %.1f%% C%d N%d", clamp_probability(probability), channel + 1, pitch)
end

local function parse_marker(text)
  local probability, channel, pitch = text:match("^P%s+(%d+%.?%d*)%%%s+C(%d+)%s+N(%d+)$")
  if probability and channel and pitch then
    channel, pitch = tonumber(channel) - 1, tonumber(pitch)
    if channel >= 0 and channel <= 15 and pitch >= 0 and pitch <= 127 then
      return clamp_probability(probability), channel, pitch
    end
  end
  return nil
end

local function marker_map(take)
  local markers = {}
  local ok, raw = reaper.MIDI_GetAllEvts(take, "")
  if not ok then return markers end
  local position, ppq = 1, 0
  while position <= #raw do
    local offset, flags, size
    offset, flags, size, position = string.unpack("<i4BI4", raw, position)
    local message = raw:sub(position, position + size - 1)
    position, ppq = position + size, ppq + offset
    if #message >= 4 and message:byte(1) == 0xFF and message:byte(2) == 1 and message:byte(3) == #message - 3 then
      local probability, channel, pitch = parse_marker(message:sub(4))
      if probability then markers[#markers + 1] = { ppq = ppq, probability = probability, channel = channel, pitch = pitch } end
    end
  end
  return markers
end

local function notes_in_take(take, selected_only)
  local notes = {}
  local _, count = reaper.MIDI_CountEvts(take)
  for index = 0, count - 1 do
    local ok, selected, _, start_ppq, end_ppq, channel, pitch, velocity = reaper.MIDI_GetNote(take, index)
    if ok and (not selected_only or selected) then
      notes[#notes + 1] = { index = index, start_ppq = start_ppq, end_ppq = end_ppq, channel = channel, pitch = pitch, velocity = velocity, probability = 100 }
    end
  end
  table.sort(notes, function(a, b) return a.index < b.index end)
  return notes
end

local function key_for(note)
  return string.format("%.9f:%d:%d", note.start_ppq, note.channel, note.pitch)
end

local function load_selection()
  local editor = reaper.MIDIEditor_GetActive()
  if not editor then return ERROR_NO_EDITOR end
  local take = reaper.MIDIEditor_GetTake(editor)
  if not take or not reaper.TakeIsMIDI(take) then return ERROR_NO_EDITOR end
  local notes = notes_in_take(take, true)
  if #notes == 0 then return ERROR_NO_SELECTION end

  local markers = marker_map(take)
  local consumed = {}
  for _, note in ipairs(notes) do
    local expected = math.max(0, note.start_ppq - MARKER_LEAD_PPQ)
    for marker_index, marker in ipairs(markers) do
      if not consumed[marker_index] and marker.ppq == expected and marker.channel == note.channel and marker.pitch == note.pitch then
        note.probability, consumed[marker_index] = marker.probability, true
        break
      end
    end
  end

  if #notes > MAX_NOTES_PER_CLIENT then return ERROR_INVALID end
  state.notes, state.take = notes, take
  state.generation = state.generation + 1
  reaper.gmem_write(mailbox_base + SLOT_RESULT_GENERATION, state.generation)
  reaper.gmem_write(mailbox_base + SLOT_RESULT_COUNT, #notes)
  for row, note in ipairs(notes) do
    local base = records_base + (row - 1) * RECORD_SIZE
    reaper.gmem_write(base, note.index)
    reaper.gmem_write(base + 1, note.start_ppq)
    reaper.gmem_write(base + 2, note.end_ppq)
    reaper.gmem_write(base + 3, note.channel)
    reaper.gmem_write(base + 4, note.pitch)
    reaper.gmem_write(base + 5, note.velocity)
    reaper.gmem_write(base + 6, note.probability)
  end
  return STATUS_LOADED
end

local function selection_is_current()
  if not state.take or not reaper.ValidatePtr2(0, state.take, "MediaItem_Take*") then return false end
  local current = notes_in_take(state.take, true)
  if #current ~= #state.notes then return false end
  for i, note in ipairs(current) do
    local saved = state.notes[i]
    if note.index ~= saved.index or note.start_ppq ~= saved.start_ppq or note.end_ppq ~= saved.end_ppq or note.channel ~= saved.channel or note.pitch ~= saved.pitch then return false end
  end
  return true
end

local function selection_is_unambiguous()
  local all_notes = notes_in_take(state.take, false)
  local selected_counts, all_counts = {}, {}
  for _, note in ipairs(state.notes) do selected_counts[key_for(note)] = (selected_counts[key_for(note)] or 0) + 1 end
  for _, note in ipairs(all_notes) do all_counts[key_for(note)] = (all_counts[key_for(note)] or 0) + 1 end
  for key, count in pairs(selected_counts) do
    if all_counts[key] ~= count then return false end
  end
  return true
end

local function apply_selection()
  if reaper.gmem_read(mailbox_base + SLOT_GENERATION) ~= state.generation or not selection_is_current() then return ERROR_STALE end
  if not selection_is_unambiguous() then return ERROR_AMBIGUOUS end

  for row, note in ipairs(state.notes) do
    note.probability = clamp_probability(reaper.gmem_read(records_base + (row - 1) * RECORD_SIZE + 6))
  end
  local values = {}
  for _, note in ipairs(state.notes) do
    local key = key_for(note)
    if values[key] and values[key] ~= note.probability then return ERROR_AMBIGUOUS end
    values[key] = note.probability
  end

  -- At PPQ 0 a marker cannot be placed one tick earlier, so its marker PPQ is
  -- also 0. Keep the marker positions explicitly instead of reconstructing
  -- them by adding MARKER_LEAD_PPQ during cleanup.
  local target_marker_keys = {}
  for _, note in ipairs(state.notes) do
    local marker_ppq = math.max(0, note.start_ppq - MARKER_LEAD_PPQ)
    target_marker_keys[string.format("%.9f:%d:%d", marker_ppq, note.channel, note.pitch)] = true
  end
  local ok, raw = reaper.MIDI_GetAllEvts(state.take, "")
  if not ok then return ERROR_INVALID end
  local events, position, ppq, order = {}, 1, 0, 0
  while position <= #raw do
    local offset, flags, size
    offset, flags, size, position = string.unpack("<i4BI4", raw, position)
    local message = raw:sub(position, position + size - 1)
    position, ppq, order = position + size, ppq + offset, order + 1
    local remove = false
    if #message >= 4 and message:byte(1) == 0xFF and message:byte(2) == 1 and message:byte(3) == #message - 3 then
      local _, channel, pitch = parse_marker(message:sub(4))
      if channel then remove = target_marker_keys[string.format("%.9f:%d:%d", ppq, channel, pitch)] or false end
    end
    if not remove then events[#events + 1] = { ppq = ppq, flags = flags, message = message, order = order, marker = false } end
  end
  for _, note in ipairs(state.notes) do
    if note.probability < 100 then
      local text = marker_text(note.probability, note.channel, note.pitch)
      events[#events + 1] = { ppq = math.max(0, note.start_ppq - MARKER_LEAD_PPQ), flags = 0, message = string.char(0xFF, 1, #text) .. text, order = note.index, marker = true }
    end
  end
  table.sort(events, function(a, b)
    if a.ppq ~= b.ppq then return a.ppq < b.ppq end
    if a.marker ~= b.marker then return a.marker end
    return a.order < b.order
  end)
  local output, previous_ppq = {}, 0
  for _, event in ipairs(events) do
    output[#output + 1] = string.pack("<i4BI4", event.ppq - previous_ppq, event.flags, #event.message) .. event.message
    previous_ppq = event.ppq
  end
  reaper.Undo_BeginBlock()
  reaper.MIDI_SetAllEvts(state.take, table.concat(output))
  reaper.MIDI_Sort(state.take)
  reaper.Undo_EndBlock("Set Stomata note probabilities", -1)
  reaper.UpdateArrange()
  return STATUS_APPLIED
end

local function service()
  reaper.gmem_write(SLOT_MAGIC, MAGIC)
  reaper.gmem_write(SLOT_HEARTBEAT, reaper.time_precise())
  for client = 0, MAX_CLIENTS - 1 do
    mailbox_base = CLIENT_TABLE_BASE + client * CLIENT_MAILBOX_SIZE
    local token = reaper.gmem_read(mailbox_base)
    if token ~= 0 then
      state = states[client]
      if not state or state.token ~= token then
        state = { token = token, request_id = 0, generation = 0, notes = {}, take = nil }
        states[client] = state
      end
      records_base = CLIENT_RECORDS_BASE + client * MAX_NOTES_PER_CLIENT * RECORD_SIZE
      local request_id = reaper.gmem_read(mailbox_base + SLOT_REQUEST_ID)
      if request_id > state.request_id then
        state.request_id = request_id
        local command, result = reaper.gmem_read(mailbox_base + SLOT_COMMAND), ERROR_INVALID
        if command == COMMAND_REFRESH then result = load_selection()
        elseif command == COMMAND_APPLY then result = apply_selection() end
        reaper.gmem_write(mailbox_base + SLOT_STATUS, result)
        reaper.gmem_write(mailbox_base + SLOT_RESPONSE_ID, request_id)
      end
    end
  end
  reaper.defer(service)
end

service()
